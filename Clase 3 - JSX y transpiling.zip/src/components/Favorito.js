const Favorito = () => {
    return ( 
        <>
       <span class="material-icons">favorite_border</span>
        </>
     );
}
 
export default Favorito;