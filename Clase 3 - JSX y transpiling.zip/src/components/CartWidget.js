const CartWidget = () => {
    return ( 
        <>
        <span class="material-icons">shopping_bag</span>
        </>
     );
}
 
export default CartWidget;